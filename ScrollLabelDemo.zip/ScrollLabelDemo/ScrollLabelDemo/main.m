//
//  main.m
//  ScrollLabelDemo
//
//  Created by 于海涛 on 16/7/24.
//  Copyright © 2016年 于海涛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
